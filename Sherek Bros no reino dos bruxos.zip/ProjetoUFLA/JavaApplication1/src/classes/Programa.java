package classes;

/**
 * Classe main do jogo, nessa classe apenas será chamado o método jogo.
 * @author Vinicius
 */
public class Programa {

	public static void main(String[] args) {
		Jogo jogo = new Jogo();
		
		jogo.jogar();
	}

}
