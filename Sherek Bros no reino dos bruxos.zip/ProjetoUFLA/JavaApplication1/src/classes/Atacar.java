package classes;

/**
 * Essa interface é para que as classes, arco,espada e chicote possam usar o método atacar.
 */

public interface Atacar {
    public void atacarDragao();
}
